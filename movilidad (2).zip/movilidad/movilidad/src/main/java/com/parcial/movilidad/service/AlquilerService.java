package com.parcial.movilidad.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.parcial.movilidad.exception.*;
import com.parcial.movilidad.factory.MetodoPagoFactory;
import com.parcial.movilidad.model.*;
import com.parcial.movilidad.pago.MetodoPago;

@Service
public class AlquilerService {

    private Estacion estacion;

    private List<Usuario> usuarios;

    public AlquilerService() {

        estacion = new Estacion("Centro");

        estacion.agregarVehiculo(
                new Monopatin(
                        "AAA111",
                        80,
                        1000,
                        true));

        usuarios = new ArrayList<>();

        usuarios.add(
                new UsuarioRegular(
                        1,
                        "Juan"));

        usuarios.add(
                new UsuarioPremium(
                        2,
                        "Ana",
                        0.20));
    }

    public Usuario buscarUsuario(int id) {

        for (Usuario u : usuarios) {

            if (u.getId() == id) {

                return u;
            }
        }

        return null;
    }

    public String desbloquear(int idUsuario,
                              String patente,
                              String metodoPago) {

        Vehiculo v =
                estacion.buscarVehiculo(patente);

        if (v == null) {

            throw new VehiculoNoEncontradoException(
                    "Vehiculo no encontrado");
        }

        if (v.getBateria() < 15) {

            throw new BateriaInsuficienteException(
                    "Bateria insuficiente");
        }

        Usuario u = buscarUsuario(idUsuario);
        if (u == null) {

    return "Usuario no encontrado";
}

        double total =
                u.calcularTarifa(
                        v.getTarifaBase());

        MetodoPago pago =
                MetodoPagoFactory
                        .crearMetodo(metodoPago);

        pago.cobrar(total);

        return "Vehiculo desbloqueado";
    }
}