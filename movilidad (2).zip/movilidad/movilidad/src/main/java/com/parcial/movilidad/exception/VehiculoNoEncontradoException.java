package com.parcial.movilidad.exception;

public class VehiculoNoEncontradoException
        extends RuntimeException {

    public VehiculoNoEncontradoException(String mensaje) {

        super(mensaje);
    }
}