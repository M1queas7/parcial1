package com.parcial.movilidad.model;

public class BicicletaElectrica extends Vehiculo {

    private double canasto;

    public BicicletaElectrica(String patente,
                              int bateria,
                              double tarifaBase,
                              double canasto) {

        super(patente, bateria, tarifaBase);

        this.canasto = canasto;
    }
}