package com.parcial.movilidad.pago;

public class PagoTarjeta implements MetodoPago {

    @Override
    public void cobrar(double monto) {

        System.out.println("Pago con tarjeta");
    }
}