package com.parcial.movilidad.model;

public class UsuarioPremium extends Usuario {

    private double descuento;

    public UsuarioPremium(int id,
                          String nombre,
                          double descuento) {

        super(id, nombre);

        this.descuento = descuento;
    }

    @Override
    public double calcularTarifa(double tarifa) {

        return tarifa - (tarifa * descuento);
    }
}