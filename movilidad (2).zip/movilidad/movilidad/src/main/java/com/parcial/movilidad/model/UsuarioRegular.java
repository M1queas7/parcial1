package com.parcial.movilidad.model;

public class UsuarioRegular extends Usuario {

    public UsuarioRegular(int id,
                          String nombre) {

        super(id, nombre);
    }

    @Override
    public double calcularTarifa(double tarifa) {

        return tarifa;
    }
}