package com.parcial.movilidad.pago;

public interface MetodoPago {

    void cobrar(double monto);
}
