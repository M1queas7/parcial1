package com.parcial.movilidad.controler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.parcial.movilidad.dto.SolicitudDTO;
import com.parcial.movilidad.service.AlquilerService;

@RestController
@RequestMapping("/api/alquileres")
public class AlquilerController {

    @Autowired
    private AlquilerService service;

    @PostMapping("/desbloquear")
    public String desbloquear(
            @RequestBody SolicitudDTO dto) {

        return service.desbloquear(
                dto.getIdUsuario(),
                dto.getPatente(),
                dto.getMetodoPago());
    }
}