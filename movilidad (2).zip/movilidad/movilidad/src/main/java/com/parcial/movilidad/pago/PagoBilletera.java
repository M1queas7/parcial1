package com.parcial.movilidad.pago;

public class PagoBilletera implements MetodoPago {

    @Override
    public void cobrar(double monto) {

        System.out.println("Pago con billetera");
    }
}