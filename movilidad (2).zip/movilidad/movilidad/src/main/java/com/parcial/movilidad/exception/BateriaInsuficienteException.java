package com.parcial.movilidad.exception;

public class BateriaInsuficienteException
        extends RuntimeException {

    public BateriaInsuficienteException(String mensaje) {

        super(mensaje);
    }
}
