package com.parcial.movilidad.factory;

import com.parcial.movilidad.pago.*;

public class MetodoPagoFactory {

    public static MetodoPago crearMetodo(String tipo) {

        if (tipo.equalsIgnoreCase("tarjeta")) {

            return new PagoTarjeta();
        }

        return new PagoBilletera();
    }
}